<?php

$con = mysqli_connect("localhost", "root", "", "vehiclepooling") or die("error");
