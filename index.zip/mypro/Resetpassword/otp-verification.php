<div class="err"></div>
<div class="success"></div>
<form id="#mobile-number-verification" style="padding:15px;border-radius:15px;">
    <div class="mobile-row">
        <label>OTP is sent to Your Email id</label>
    </div>

    <div class="mobile-row">
        <input type="number" id="mobileOtp" class="mobile-input" placeholder="Enter the OTP">
    </div>

    <div class="mobile-row">
        <input id="verify" type="button" class="btnVerify" value="Verify OTP" onClick="verifyOTP();">
    </div>
</form>