<?php 
	$conn=new mysqli("localhost","root","","vehiclepooling");
	
	$response = array();
	$usid =$_POST['ids'];
		//	$id = $_POST['ids'];
            //$username='reny.jose@mariancollege.org';
            // $id='9';
				$ats="select * from vhlbooking where userid='$usid' ";
				 $res=mysqli_query($conn,$ats);	
				$products=array();
				if(mysqli_num_rows($res)>0)
							{
					            while($row=mysqli_fetch_array($res)) {
									
								$a = $row['frm'];
								$b = $row['ttoo'];
								$c = $row['rrouts'];
								$d = $row['ddate'];
								$e = $row['ttime'];
								$f = $row['ttlseat'];
								$g = $row['aamount'];
							
								
								//$dts="select deptname from departments019 where id='$d'";
								// $res2=mysqli_query($conn,$dts);
								
								$temp = array(						       
								   'from'=>$a, 
							         'to'=>$b,
									 'routs'=>$c, 
									 'dates'=>$d, 
									 'times'=>$e, 
									 'totseats'=>$f,  
									 'amounts'=>$g, 
									
								
						               );
									   array_push($products, $temp);
									}
				 }
			
			     
		
	echo json_encode($products);
	
	?>