<?php
include('nav1.php');
?>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>


<script type = "text/javascript">
   
      function validate() {
        var password1=document.myForm.passwd.value;  
        var password2=document.myForm.repasswd.value; 
        
        
       if (document.myForm.fname.value=="")
    {
      document.getElementById('fn').innerHTML="**Enter fullname";
      return false;
    }

    if (document.myForm.uname.value=="")
    {
      document.getElementById('unam').innerHTML="**Enter Username";
      return false;
    }
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (document.myForm.mail.value=="" || !filter.test(document.myForm.mail.value))
    {
    document.getElementById('em').innerHTML="**Enter a valid Email";
    return false;
    }
 if (document.myForm.phone.value=="")
    {
      document.getElementById('pn').innerHTML="**Enter Phone";
      return false;
    }
    var val = document.myForm.phone.value;
if (/^\d{10}$/.test(val)==false) {
    // value is ok, use it
document.getElementById('pn').innerHTML="**No must be 10 digit";
   
    return false;
}
 if (document.myForm.place.value=="")
    {
      document.getElementById('pl').innerHTML="**Enter Place";
      return false;
    }
 if (document.myForm.state.value=="")
    {
      document.getElementById('st').innerHTML="**Enter State";
      return false;
    }
var valpin = document.myForm.pin.value;
if (/^\d{6}$/.test(valpin)==false) {
    // value is ok, use it
document.getElementById('pi').innerHTML="**Pin must be 6 digit";
   
    return false;
}


 if (document.myForm.licence.value=="")
    {
      document.getElementById('ln').innerHTML="**Enter DOB";
      return false;
    }
 if (document.myForm.aadhar.value=="")
    {
      document.getElementById('ad').innerHTML="**Enter Adhar";
      return false;
    }
var valadhar = document.myForm.aadhar.value;
if (/^\d{18}$/.test(valadhar)==false) {
    // value is ok, use it
 document.getElementById('ad').innerHTML="**Adhar no must be 18 digit";
   
    return false;
}
 if (document.myForm.passwd.value=="")
    {
      document.getElementById('pa').innerHTML="**Enter Password";
      return false;
    }
 if (document.myForm.repasswd.value=="")
    {
      document.getElementById('cpa').innerHTML="**Enter Confirm password";
      return false;
    }
 if (password1 != password2) {
              alert ("\nPassword did not match: Please try again....");
             return false;
          }


      }
   
</script>
  </head>
  <body class="p-3 mb-2 bg-dark text-white"">
      <br>
      <center><h1>Sign Up</h1></center>
    <form name="myForm" method="POST" action="#" enctype="multipart/form-data" onsubmit = "return(validate());">

                        <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                <label class="form-label">Full Name <span id="fn" style="color:red;"></span></label><label style="color:red;"> *</label>
                                <input type="text" value="" class="form-control" id="fname" name="fname">
                                </div>
                            </div>
                            <div class="col">

                                <div class="mb-3">
                                <label class="form-label">User Name <span id="unam" style="color:red;"></span></label><label style="color:red;"> *</label>
                                <input type="text" value=""  class="form-control" id="uname" name="uname">
                                </div>
                            </div>
                            <div class="col">
                             <div class="mb-3">
                                <label  class="form-label">User Type</label><label style="color:red;"> *</label>
                                        <select class="form-select col-4" aria-label="Default select example" id="usertype" name="usertype">
                                        <option value="Vehicle_Owner">Vehicle Owner</option>
                                        <option value="Vehicle_User">Vehicle User</option>
                                        </select> 
                              </div>
                             </div>
                            </div>
                            <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                <label class="form-label">Email address<span id="em" style="color:red;"></span></label><label style="color:red;"> *</label>

                                <input type="text" class="form-control" id="mail" name="mail" value="" >

                                <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>

                                </div>

                            </div>

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">phone<span id="ph" style="color:red;"></span></label><label style="color:red;"> *</label>

                                <input type="text" class="form-control" id="phone" name="phone" value="">

                                </div>

                            </div>

                            

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Date Of Birth</label><label style="color:red;"> *</label>

                                <input type="date" class="form-control" id="dob" name="dob" value="" max="<?= date('Y-m-d'); ?>"/>
                                </div>
                            </div>    
                            </div>
                            <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label  class="form-label">Place<span id="pl" style="color:red;"></span></label><label style="color:red;"> *</label>

                                <input type="text" class="form-control" id="place" name="place" value="">

                                </div>

                            </div>

                            <div class="col">

                                <div class="mb-3">

                                <label  class="form-label">State</label><label style="color:red;"> *</label>

                                <div class="container">

                                    <div class="row">

                                        <select class="form-select col-4" aria-label="Default select example" id="state" name="state">
                                        <option value="Kerala">Kerala</option>
                                        <option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Puducherry">Puducherry</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>

<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="West Bengal">West Bengal</option>

                                        

                                        </select> 

                                    </div>

                              </div>


                                </div>

                            </div>

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Country</label><label style="color:red;"> *</label>

                                <div class="container">

                                    <div class="row">

                                        <select class="form-select col-4" aria-label="Default select example" id="country" name="country">
                                        <option value="India">India</option>
                                        </select> 

                                    </div>

                              </div>


                                </div>

                            </div>

                            </div>
<div class="row">
 

                            <div class="col">

<div class="mb-3">

<label  class="form-label">District</label><label style="color:red;"> *</label>

<input type="text" class="form-control" id="district" name="district" value="">
</div>

</div>

                            <div class="col">

                             <div class="mb-3">

                                <label  class="form-label">Gender</label><label style="color:red;"> *</label>
                                        <select class="form-select col-4" aria-label="Default select example" id="gender" name="gender">
                                        <option value="MALE">MALE</option>
                                        <option value="FEMALE">FEMALE</option>
                                        <option value="FEMALE">OTHER</option>
                                        </select> 
                              </div>

                             </div>

                            
                             <div class="col">

<div class="mb-3">

<label  class="form-label">Aadhaar No<span id="ad" style="color:red;"></span></label><label style="color:red;"> *</label>

<input type="text" class="form-control" id="aadhar" name="aadhar" value="">
</div>

</div>  
 </div>

                <div class="row">
 

                            <div class="col">

                                <div class="mb-3">

                                 <label  class="form-label">Licence Id<span id="ln" style="color:red;"></span></label><label style="color:red;"> *</label>

                                 <input type="text" class="form-control" id="licence" name="licence" value="">
                               </div>
                            </div>
                            <div class="col">

                                <div class="mb-3">

                                 <label  class="form-label">Password<span id="pa" style="color:red;"></span></label><label style="color:red;"> *</label>

                                 <input type="text" class="form-control" id="passwd" name="passwd" value="">
                               </div>
                            </div>
                            <div class="col">

                                <div class="mb-3">

                                 <label  class="form-label">Re Enter Password<span id="cpa" style="color:red;"></span></label><label style="color:red;"> *</label>

                                 <input type="text" class="form-control" id="repasswd" name="repasswd" value="">
                               </div>
                            </div>
                           


</div>
<div class="row">
<div class="col">

<div class="mb-3">

<img id="uploadPreview" style="width: 100px; height: 100px;" />
<input id="uploadImage" type="file" accept="image/*" name="myPhoto" onchange="PreviewImage();" />
<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>
</div>
</div>
<center><div class="col-12">
<button type="submit" name="reginsert" class="btn btn-primary col-2">Sign up</button></center>
</div>

                            
  </body>
</html>
<?php
include("connect.php");

  if(isset($_POST["reginsert"]))
  {

    
    $fname=$_POST["fname"];
    $Username=$_POST["uname"];
    $usertype=$_POST["usertype"];
    $email=$_POST["mail"];
    $phone=$_POST["phone"];
    $dob=$_POST["dob"];
    $place=$_POST["place"];
    $state=$_POST["state"];
    $country=$_POST["country"];
    $gender=$_POST["gender"];

    $aadhar=$_POST["aadhar"];
    
    $licence=$_POST["licence"];
    $passwd=$_POST["repasswd"];
    
    
   
 
 $msg="";
 $imgpath=$_FILES["myPhoto"]["name"];

// check if the user has clicked the button "UPLOAD" 

    $filename = $_FILES["myPhoto"]["name"];

    $tempname = $_FILES["myPhoto"]["tmp_name"];  


        $folder = "owner/propic/".$filename;   
      if (move_uploaded_file($tempname, $folder)) {

            $msg = "Image uploaded successfully";

        }else{

           $imgpath="user.png";
    }
    $sql="INSERT INTO `registration`(`name`, `username`, `usertype`, `email`, `phone`, `dob`, `place`, `state`, `country`, `gender`,
    `aadhar`,`Licence_id`,`password`, `path`) VALUES ('$fname','$Username','$usertype','$email','$phone','$dob','$place','$state',
    '$country','$gender','$aadhar','$licence','$passwd','$imgpath')";

  if(mysqli_query($con,$sql))
  {
    ?>
    <script>
        alert("inserted");
    </script>
    <?php
  }
  else
  {
    echo "error";
  }
  
    }
  ?>
