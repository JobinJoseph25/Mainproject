<?php
$host = "localhost"; $username = "root"; $passwd = ""; $dbname = "vehiclepooling";
$con = mysqli_connect($host, $username, $passwd, $dbname)or die ("not connected ");
?>