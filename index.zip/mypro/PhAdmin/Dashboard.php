
<?php
include 'adnav.php';
include 'connect.php';

$query = "select * FROM registration where usertype='Vehicle_Owner'";
 $result = $con->query($query);
 $rowcount = mysqli_num_rows( $result );
    $total = $rowcount;

$q2 = "select * FROM registration where usertype='Vehicle_User'";
 $r2 = $con->query($q2);
 $ro2 = mysqli_num_rows( $r2 );
    $total2 = $ro2;

    $q3 = "select * FROM addtraveldetails";
 $r3 = $con->query($q3);
 $ro3 = mysqli_num_rows( $r3 );
    $total3 = $ro3;


    $q4 = "select * FROM registration where Statuss=1";
 $r4 = $con->query($q4);
 $ro4 = mysqli_num_rows( $r4);
    $total4 = $ro4;

?>
<br><br><br><br>
 <div class="row">
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Total Vehicle Owners</h5>
        <h1><?php echo  $total; ?></h1>
      </div>
    </div>
  </div>  
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
      <h5 class="card-title">Total Vehicle Users</h5>
        <h1><?php echo  $total2; ?></h1>
      </div>
    </div>
    
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
      <h5 class="card-title">Total no of travels</h5>
        <h1><?php echo  $total3; ?></h1>
      </div>
    </div>
    
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
      <h5 class="card-title">Blocked Users</h5>
        <h1><?php echo  $total4; ?></h1>
      </div>
    </div>
    
  </div>
</div>