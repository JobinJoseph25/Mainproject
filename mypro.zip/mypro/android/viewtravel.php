
            <?php 
	$conn=new mysqli("localhost","root","","vehiclepooling");

$response = array();

        $tvlidd =$_POST['travelid'];
       
      
		
		//	$id = $_POST['ids'];
            //$username='reny.jose@mariancollege.org';
            // $id='9';
				$ats="select * from addtraveldetails,addvehicle,registration where (addtraveldetails.t_uid=(addvehicle.uid & registration.id)) &
                (addtraveldetails.tvlid='$tvlidd') ;";
				
				 $res=mysqli_query($conn,$ats);
				
				$products=array();
				if(mysqli_num_rows($res)>0)
							{
					            while($row=mysqli_fetch_array($res)) {
									
								$a = $row['name'];
								$b = $row['froms'];
								$c = $row['tos'];
								$d = $row['no_of_seats'];
								$e = $row['dates'];
								$f = $row['times'];
								$g = $row['amount'];
								$h = $row['routs'];

								$i = $row['imgpath'];
								$j = $row['path'];
								$k = $row['model_name'];
								$l = $row['tvlid'];
                                $m = $row['Fueltype'];
                                $n = $row['Build_year'];

                                $o = $row['email'];
                                $p = $row['phone'];
                                $q = $row['username'];
                                $r = $row['place'];
                             
							
								//$dts="select deptname from departments019 where id='$d'";
								// $res2=mysqli_query($conn,$dts);
								
								$temp = array(						       
								   'ownername'=>$a, 
							         'from'=>$b,
									 'to'=>$c, 
									 'no_of_seats'=>$d, 
									 'dates'=>$e, 
									 'times'=>$f,  
									 'amount'=>$g, 
									 'routs'=>$h, 
									 'vimage'=>$i, 
									 'propic'=>$j, 
									 'model_name'=>$k, 
									 'tvlid'=>$l,
                                     'fueltype'=>$m,
                                     'buildyear'=>$n,
                                     'email'=>$o,
                                     'phone'=>$p,
                                     'username'=>$q,
                                     'place'=>$r,
						               );
									   array_push($products, $temp);
									}
				 }
			
			     
		
	echo json_encode($products);
            
            
?>		