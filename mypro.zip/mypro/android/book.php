<?php 
	$conn=new mysqli("localhost","root","","vehiclepooling");
	
	$response = array();
	$tvlid =$_POST['travelid'];
    $usrid =$_POST['userid'];
    $seatsneed =$_POST['seatsneed'];
    $tt=mysqli_query($conn,"SELECT registration.id,registration.name,registration.email,registration.phone,registration.place FROM 
    registration,addtraveldetails WHERE (registration.id=addtraveldetails.t_uid) and (addtraveldetails.tvlid=$tvlid)");
    $res=mysqli_fetch_array($tt);
$ownerid=$res['id'];
$name=$res['name'];
$email=$res['email'];
$phone=$res['phone'];
$place=$res['place'];

$uu=mysqli_query($conn,"SELECT `froms`, `tos`, `routs`, `dates`, `times`, `no_of_seats`, `amount` FROM `addtraveldetails` WHERE t_uid='$ownerid'");
$res1=mysqli_fetch_array($uu);
$from=$res1['froms'];
$tos=$res1['tos'];
$routs=$res1['routs'];
$times=$res1['times'];
$dates=$res1['dates'];
$ttlseat=$res1['no_of_seats'];
$amount=$res1['amount'];

$sql="INSERT INTO `vhlbooking`(`ownerid`, `userid`, `travelid`, `frm`, `ttoo`, `rrouts`,`pickupdest`, `ttlseat`, `ddate`, `ttime`, `aamount`, 
`sseatsneeded`, `owner_name`, `owner_email`, `owner_phone`, `owner_place`, `paymentstat`,`proof`, `bkstatus`)
 VALUES ('$ownerid','$usrid','$tvlid','$from','$tos','$routs','$from','$ttlseat','$dates','$times',
 '$amount','$seatsneed','$name','$email','$phone','$place','unpaid','proof.pdf','processing')";
if(mysqli_query($conn,$sql))
{
    $response['message'] = '1';
}
else{
    $response['message'] = '0';
}

echo json_encode($response);

    ?>