
            <?php 
	$con=new mysqli("localhost","root","","vehiclepooling");

$response = array();

        $email =$_POST['username'];
        $pass=$_POST['password'];
        //$username='reny.jose@mariancollege.org';
        // $id='9';
            
             $st_check=$con->prepare("select id,name from registration  where email=? and password=?");
             $st_check->bind_param("ss",$email,$pass);
             $st_check->execute();
             
             $st_check->store_result();
             $response = array();
         
             if($st_check->num_rows > 0){
                             
                 $st_check->bind_result($id, $username);
                 $st_check->fetch();
                 
                 $user = array(
                     'id'=>$id, 
                     'username'=>$username, 
                 );
                 $st_check->close();
							
							$response['error'] = false; 
							$response['message'] = '1'; 
							$response['user'] = $user; 
                 
             }
             else{
                 $response['error'] = true; 
                 $response['message'] = '2'; 
             }
            
             
    
 echo json_encode($response);

//displaying the result in json format 

            
            
?>		