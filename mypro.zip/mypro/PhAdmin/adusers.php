<?php
include 'adnav.php';
include 'connect.php';
?>
<div class="row">
        <div class="col-lg-12" style="margin-top: 50px; margin-bottom: 50px;">
         
            <h2>Added Vehicles</h2>

            <!--Start table -->
            <table id="example" class="table table-striped table-bordered" style="width:100%"  >

                <thead>
                  <tr>
                    <!-- <th scope="col">ID</th> -->
                    
                    <th scope="col">Pic</th>
                    <th scope="col">Name</th>
                    <th scope="col">UserName</th>
                    <th scope="col">User Type</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">DOB</th>
                    <th scope="col">place</th>
                    <th scope="col">state</th>
                    <th scope="col">country</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Aadhar</th>
                    <th scope="col">Licence_id</th>
                    <th scope="col">Status</th>
                    <th scope="col">    </th>
                    <!-- <th scope="col">Add Date</th>
                    <th scope="col">Price</th> -->
                    
                              <!-- <th scope="col">Drop</th> -->
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $usid='11';
                    $query2=mysqli_query($con,"select * from registration");  
    while($result=mysqli_fetch_array($query2))
  { 
 
   ?>
   <?php
    echo'<tr>';


    echo "<td><img width='100px' height='100px' src='..\owner/propic/".$result['path']."'</td>";
    echo "<td>".$result['name']."</td>";
    echo "<td>".$result['username']."</td>";
    echo "<td>".$result['usertype']."</td>";
    echo "<td>".$result['email']."</td>";
    echo "<td>".$result['phone']."</td>";

    echo "<td>".$result['dob']."</td>";
    echo "<td>".$result['place']."</td>";
    echo "<td>".$result['state']."</td>";
    echo "<td>".$result['country']."</td>";
    echo "<td>".$result['gender']."</td>";
    echo "<td>".$result['aadhar']."</td>";
    echo "<td>".$result['Licence_id']."</td>";
    echo "<td>".$result['Statuss']."</td>";
?>

<?php

include("connect.php");
$g=$result['id'];
 
 $q6="select Statuss from registration where id='$g'";
 $r6 = $con->query($q6);
 if ($r6->num_rows > 0) {
     while($ro6 = $r6->fetch_assoc())
      {
     $status=$ro6["Statuss"];
    if($status==0)
    {
     $a="Block";
    }
     else if($status==1)
    {
     $a="Unblock";
    }
    
   }
   
}  
?>  
   
  <?php  echo "<td>"
  ?>
  <form  action='adusers.php' method="POST" enctype="multipart/form-data">
   <input type='hidden' name='userid' value="<?php echo $result["id"]; ?>">
  <input type='submit' name="<?php echo $a; ?>" value="<?php echo $a; ?>" class='btn btn-outline-success btn-sm'>
  </form>
  <?php "
   </td>";

    echo '</tr>';
?>

 <?php
  }
?> 
                
            </tbody>  
            </table>
            <!--end table -->

        </div>
      </div>
      <!-- /.row -->
      <?php
 include("connect.php");

  if(isset($_POST["Block"])){

      $st=$_POST["userid"];
     
   
      $sl="update registration set Statuss=1 where id='$st'";
  if(mysqli_query($con,$sl))
  {
   echo("<meta http-equiv='refresh' content='1'>"); 
  }
else
{
  echo "error";
}



      
  
  }
?>
<?php
 include("connect.php");

  if(isset($_POST["Unblock"])){

    $stv=$_POST["userid"];
     
     
    $sm="update registration set Statuss=0 where id='$stv'";

  if(mysqli_query($con,$sm))
  {
 echo("<meta http-equiv='refresh' content='1'>"); 
  }
else
{
  echo "error";
}

     

      
  
  }
?>

