<?php
include 'adnav.php';
include 'connect.php';
?>
<br>
<br>
<center><h1>
     Payment History
</h1>
</center><form method="POST" action="traveldetails.php">
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Username</th>
      <th scope="col">Ownername</th>
      <th scope="col">Paid Amount</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
  <?php
                 
                    $query2=mysqli_query($con,"select * from tbl_payment");  
    while($result=mysqli_fetch_array($query2))
  { 
 $a=$result['p_userid'];
 $query22=mysqli_query($con,"select name,path from registration where id=$a");  
 $result2=mysqli_fetch_array($query22);
 $ii=$result2['path'];
$b=$result['p_ownerid'];
 $q2=mysqli_query($con,"select name,path from registration where id=$b");  
 $r2=mysqli_fetch_array($q2);
 $i=$r2['path'];
   ?>
    <tr>
      <th scope="row">1</th>
      <td><img src="..\owner/propic/<?php echo $ii; ?>" style="height:50px"><?php echo $result2['name'] ?></td>
      <td><img src="..\owner/propic/<?php echo $i; ?>" style="height:50px"><?php echo $r2['name'] ?></td>
      <td><?php echo $result['p_amount'] ?></td>
      <input type="hidden" name="ttvlid" value="<?php echo $result['p_tvlid'];?>">
      <td><button type="submit" name="bktn" class="btn btn-primary col-12">View Travel Details</button></td>
    </tr>
    
  </form>
  <?php
  }
  ?>
  </tbody>

</table>