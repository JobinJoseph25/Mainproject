<?php
include 'adnav.php';
include 'connect.php';

?>
<!DOCTYPE html>
<html>
<head>
	<style>

.btn1 {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
th {
  text-align: left;
}
h1{
	color: black;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">   
    
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <script>
      function submit()
      {
        form.submit();
      }
          </script>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
<style>
    .container {
  padding: 10px;
}

ul li {
  list-style: none;
}
th{
  margin:10px;
  padding:10px;

}
</style>

</head>
<body style="background: url(bookin.jpg);
  background-repeat: no-repeat;
  background-size: 1600px;">
	<title >Booking</title>
	


  
<div class="container">
<div class="row">

<div class="col">

    <div class="mb-3">

    <label class="form-label">Full Name <span id="fn" style="color:red;"></span></label><label style="color:red;"> *</label>

    <input type="text" value="" class="form-control" id="fname" name="fname">

    </div>

</div>
<div class="row">

<div class="col">

    <div class="mb-3">

    <label class="form-label">Place <span id="fn" style="color:red;"></span></label><label style="color:red;"> *</label>

    <input type="text" value="" class="form-control" id="fname" name="fname">

    </div>

</div>
 <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Routs <span id="fn" style="color:red;"></span></label><label style="color:red;"> *</label>

                                <input type="text" value="" class="form-control" id="fname" name="fname">

                                </div>

                            </div>


</div>

  
</body>

</html>
<?php

?>