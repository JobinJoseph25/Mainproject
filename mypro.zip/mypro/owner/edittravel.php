<?php
include 'nav.php';
include 'connect.php';

  if(isset($_POST["Ed1"]))
  {
     $vid=$_POST['vid'];
    
      $qu2=mysqli_query($con,"select * from addtraveldetails where tvlid='$vid'");  
     $result=mysqli_fetch_array($qu2);

  
  
  
?>

<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">     
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

  </head>
  <body>
    <br><center><h1><b>Add Vehicle Details</b></h1></center><br>
    <form name="profile" action="#" method="POST" enctype="multipart/form-data">

                        <div class="container">

                        <div class="row">

                        <div class="col">

                        <div class="mb-3">

                                <label  class="form-label">From</label><label style="color:red;"> *</label>

                                <input type="text" value="<?php echo $result['froms']; ?>" class="form-control" id="modelname" name="from1">

                                </div>

                        </div>

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">To</label><label style="color:red;"> *</label>

                                <input type="text" value="<?php echo $result['tos']; ?>"  class="form-control" id="modelno" name="to1">

                                </div>

                            </div>

                            </div>
                            
                            <div class="row">

<div class="col">

<div class="mb-3">

        <label  class="form-label">Rout map</label><label style="color:red;"> *</label>

        <input type="text" value="<?php echo $result['routs']; ?>" class="form-control" id="rout" name="rout" placeholder="You can enter places between From and To with each seperated by Space">

        </div>
</div>
  
    </div>






                            <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label  class="form-label">Date</label><label style="color:red;"> *</label>

                                <input type="Date" class="form-control" id="Vehiclenumber" name="date1" value="<?php echo $result['dates']; ?>" >


                                </div>

                            </div>

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Time</label><label style="color:red;"> *</label>

                                <input type="Time" class="form-control" id="buildyear" name="time1" value="<?php echo $result['times']; ?>">

                                </div>

                            </div>

                            </div>
                            <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">No Of Seats</label><label style="color:red;"> *</label>
                                <input type="text" value="<?php echo $result['no_of_seats']; ?>"  class="form-control" id="modelno" name="no_of_seat">

                                </div>

                            </div>        
 <div class="col">
                                <label  class="form-label">amount</label><label style="color:red;"> *</label>
                                <div class="container">
                                <input type="text" value="<?php echo $result['amount']; ?>"  class="form-control" id="modelno" name="amount">
                                </div>       
                            </div>
                        </div>
                        <input type="hidden" value="<?php echo $vid; ?>" name="vvid">

                            <center><div class="col-12">
                                <button type="submit" name="smtupp" class="btn btn-primary col-2">UPDATE</button>
                            </div></center>
                            
                    </form>


<?php
  }
include("connect.php");

  if(isset($_POST["smtupp"]))
   {
   
      $userid=$_SESSION['uid'];
      $tvlid=$_POST["vvid"];

     $from1=$_POST["from1"];
    $to1=$_POST["to1"];
    $date1=$_POST["date1"];
    $time1=$_POST["time1"];
    $no_of_seat=$_POST["no_of_seat"];
    $amount=$_POST["amount"];
    $rt=$_POST["rout"];
    
   
 
    $sql=mysqli_query($con,"UPDATE `addtraveldetails` SET
     `froms`='$from1',`tos`='$to1',`routs`='$rt',
     `dates`='$date1',`times`='$time1',`no_of_seats`='$no_of_seat',`amount`='$amount' WHERE tvlid='$tvlid'");
      

  if($sql)
  {
    ?>
    <script>
        alert("updated");
        </script>
        <?php
        header("location:travelview.php");
  }
else
{
  echo "error";
} 
  }
  ?>
  </body>
</html>