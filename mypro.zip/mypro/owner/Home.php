 <?php
 
 include 'nav.php';
 include("connect.php");
 if(isset($_SESSION['uid']))
 {
	


?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="styleindex2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
	</head>
	<body>
<body background="m.png">
	<div class="banner-area">
	
	
		<div class="banner-text">
			<h2>Vehicle Sharing Service</h2>
			<p>Welcome Back Keep share on your daily Rides</p>
			<a href="addtravel.php">ADD Travel</a>
			<a href="travelview.php">View</a>
		</div>
	</div>

</body>
	</body>
</html>
 <?php 
 }
 else{
	header("location:index.php");
 }
?>