<?php
include 'nav.php';
include 'connect.php';

$jj=$_POST['vid'];
  
  
//echo $jj;
$iiid=$_SESSION['uid'];
?>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">     
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

  </head>
<body ><div class="container">
<div class="row">
        <div class="col-lg-12" style="margin-top: 50px; margin-bottom: 50px;">
         
            <h2> Travel Requests</h2>
            <form method='POST' action='travelrequest.php'>
            <!--Start table -->
            <table id="example" class="table table-striped "  >

                <thead>
                  <tr>
                    <!-- <th scope="col">ID</th> -->
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">From</th>
                    <th scope="col">Routs</th>
                    <th scope="col">To</th>
                    <th scope="col">Total Seats</th>
                    <th scope="col">no_of_seats needed</th>
                    <th scope="col">amount</th>
                    <th scope="col">Status</th>
                    <th scope="col">Proof </th>
                    <th scope="col">Action </th>
                    <!-- <th scope="col">Add Date</th>
                    <th scope="col">Price</th> -->
                    
                              <!-- <th scope="col">Drop</th> -->
                  </tr>
                </thead>
                <tbody>
                    <?php
                       $usid=$_SESSION['uid'];
                       
$query2=mysqli_query($con,"SELECT registration.name as nm,registration.email as em,registration.phone as ph,vhlbooking.* FROM 
registration,vhlbooking WHERE (registration.id=vhlbooking.userid) & (vhlbooking.travelid='$jj') & (vhlbooking.bkstatus='processing')");  
    while($result=mysqli_fetch_array($query2))
  { 
    echo'<tr>'; 
     
    echo "<td style='color: red;'>".$result['nm']."</td>";
   
    echo "<td>".$result['em']."</td>";
    echo "<td>".$result['ph']."</td>";
    echo "<td>".$result['frm']."</td>";
    echo "<td>".$result['rrouts']."</td>";
    echo "<td>".$result['ttoo']."</td>";
    echo "<td>".$result['ttlseat']."</td>";
    echo "<td>".$result['sseatsneeded']."</td>";
    echo "<td>".$result['aamount']."</td>";
  ?>
<input type="hidden" name="ttlseat" value="<?php echo $result['ttlseat']; ?>" />
<input type="hidden" name="tseatneed" value="<?php echo $result['sseatsneeded']; ?>" />
<input type="hidden" name="tvlids" value="<?php echo $result['travelid']; ?>" />
<input type="hidden" name="emls" value="<?php echo $result['em']; ?>" />
  <?php
 
    echo "<td><select name='edtstat'><option>".$result['bkstatus']."</option><option value='Approved'>Approve</option><option value='Rejected'>Reject</option></select></td>";
   // echo "<td><img width='100px' height='100px' src='vehicleimg/".$result['imgpath']."'</td>";
   ?>
   <!-- <td><embed src="..\proof/img.pdf" type="application/pdf"   height="300px" width="100%" class="responsive"> -->
   <td><a href="..\proof/<?php echo $result['proof']; ?>" target="_blank">View</a></td>
   
<?php
    echo "<td><input type='hidden' name='bkkidd' value=".$result['bkid']."><input type='submit' name='btnstat' value='Apply' class='btn btn-success btn-sm'>&nbsp;&nbsp;
  </td></form>";
  
    echo'</tr>';

  
?>


 <?php
  }
?> 
                
            </tbody>  
            </table>
            <!--end table -->

        </div>
      </div></div>
</body>
    </html>

    <?php
  
include("connect.php");

  if(isset($_POST["btnstat"]))
   {
    $stat=$_POST["edtstat"];
   
    $tvlliddd=$_POST['tvlids'];
     $bkidd=$_POST['bkkidd'];
     $eml=$_POST['emls'];
     $ttlseat=$_POST['ttlseat'];
     $seatneeded=$_POST['tseatneed'];
     $nst=$ttlseat-$seatneeded;
    $sql=mysqli_query($con,"UPDATE `vhlbooking` SET `bkstatus`='$stat' where `bkid`='$bkidd'");
    if($stat=='Approved')
    {
    
     $sq=mysqli_query($con,"UPDATE `vhlbooking` SET `ttlseat`='$nst' where `bkid`='$bkidd'");
     
     $sqo=mysqli_query($con,"UPDATE `addtraveldetails` SET `no_of_seats`='$nst' where `tvlid`='$tvlliddd'");
    }

   // 
  if($sql)
  {
    ?>
        <?php
       
        header("location:src/verifymail.php?email=$eml");
        
  }
else
{
  echo "error";
} 
  }

  ?>