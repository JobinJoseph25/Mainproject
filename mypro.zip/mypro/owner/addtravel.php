<?php
include 'nav.php';
include 'connect.php';
?>

<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 
<!-- jQuery UI -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" />
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">     
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

  </head>
  <body>
    <br><center><h1><b>Add Travel Details</b></h1></center><br>
    <form name="profile" action="addtravel.php" method="POST" enctype="multipart/form-data">

                        <div class="container">

                        <div class="row">

                        <div class="col">

                        <div class="mb-3">

                                <label  class="form-label">From</label><label style="color:red;"> *</label>

                                <input type="text" value="" class="form-control" id="country" name="from1" required>
                                <div id="countryList"></div> 
                                </div>
                       
                    </div>
                    <script>  
 $(document).ready(function(){  
      $('#country').keyup(function(){  
           var query = $(this).val();  
           if(query != '')  
           {  
                $.ajax({  
                     url:"search.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#countryList').fadeIn();  
                          $('#countryList').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', 'li', function(){  
           $('#country').val($(this).text());  
           $('#countryList').fadeOut();  
      });  
 });  
 </script> 
                            <div class="col">
                                <div class="mb-3">
                                <label class="form-label">To</label><label style="color:red;">*</label>
                                <input type="text" value=""  class="form-control" id="to1" name="to1" required>
                                <div id="cntylist"></div> 
                                </div>
                            </div>
                            </div>
                            <script>  
 $(document).ready(function(){  
      $('#to1').keyup(function(){  
           var query = $(this).val();  
           if(query != '')  
           {  
                $.ajax({  
                     url:"search.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#cntylist').fadeIn();  
                          $('#cntylist').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', 'li', function(){  
           $('#to1').val($(this).text());  
           $('#cntylist').fadeOut();  
      });  
 });  
 </script> 



                            <div class="row">

<div class="col">

<div class="mb-3">

        <label  class="form-label">Routes map</label><label style="color:red;"> *</label>

        <input type="text" value="" class="form-control" id="rout1" name="rout" placeholder="You can enter places between From and To with each seperated by Space" required>
        <div id="cntylist2"></div> 
        </div>
</div>
<script>  
 $(document).ready(function(){  
      $('#rout1').keyup(function(){  
           var query = $(this).val();  
           if(query != '')  
           {  
                $.ajax({  
                     url:"search2.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#cntylist2').fadeIn();  
                          $('#cntylist2').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', 'li', function(){  
           $('#rout1').val($(this).text());  
           $('#cntylist2').fadeOut();  
      });  
 });  
 </script> 
    </div>

                            <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                <label  class="form-label">Date</label><label style="color:red;"> *</label>
                                <input type="Date" class="form-control" id="date1" name="date1" value="" min="<?= date('Y-m-d'); ?>" required>
                                </div>

                            </div>
                        <div class="col">
                                <div class="mb-3">
                                <label class="form-label">Time</label><label style="color:red;"> *</label>
                                <input type="Time" class="form-control" id="time1" name="time1" value="" required>
                                </div>
                            </div>

                            </div>
                            <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">No of Seats Available</label><label style="color:red;"> *</label>
                                
                                <input type="text" value="" class="form-control" id="no_of_seat" name="no_of_seat" required onChange="valset();">
<span id="msg" style="color:red;"></span>
<script>
 function valset()
  {
    var z = document.forms["profile"]["no_of_seat"].value;

if(!/^[0-9]+$/.test(z)){
  document.getElementById('msg').innerHTML="**enter numeric characters only";
  document.getElementById('no_of_seat')="";
}
  }
  </script>
                                </div>

                            </div>
                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Rate /seat</label><label style="color:red;"> *</label>
                                <input type="text" value="" class="form-control" id="amount" name="amount" required>
                                </div>

                            </div>
                            <div class="col">

<div class="mb-3">

<label class="form-label">Luggage space Avilable</label><label style="color:red;"> *</label>

<select class="form-select col-4" aria-label="Default select example" id="luggage" name="luggage">
  <option selected value="yes">YES</option>
  <option  value="no">NO</option>
  </select>
</div>

</div>
                            <div class="col">

<div class="mb-3">

   <label  class="form-label">Select_Vehicle</label><label style="color:red;"> *</label>


  

           <select class="form-select col-4" aria-label="Default select example" id="Select_Vehicle" name="Select_Vehicle">
  <option selected="selected" value="">-- Select an option --</option>
  <?php
$y=$_SESSION['uid'];
 
      $sql = "SELECT * From addvehicle WHERE uid='$y'";
      $result=mysqli_query($con,$sql);
 
      while($row=mysqli_fetch_array($result))
       
           echo "<option value='" . $row['vid'] . "'>" . $row['model_name'] ."</option>";
   ?>


           </select> 
     

 </div>

</div>
</div>
                            <center><div class="col-12">
                                <button type="submit" name="smtaddtrvl" class="btn btn-primary col-2">Add Travel</button>
                            </div></center>
                            
                    </form>


<?php



  if(isset($_POST["smtaddtrvl"]))
  {
    $userid=$_SESSION['uid'];
    $from1=$_POST["from1"];
    $to1=$_POST["to1"];
    $rt=$_POST["rout"];
    $date1=$_POST["date1"];
    $time1=$_POST["time1"];
    $no_of_seat=$_POST["no_of_seat"];
    $amount=$_POST["amount"];
    $vvid=$_POST["Select_Vehicle"];
     
    $sql=mysqli_query($con,
    "INSERT INTO `addtraveldetails`(`t_uid`, `t_vid`, `froms`, `tos`,`routs`, `dates`, `times`, `no_of_seats`, `amount`) 
    VALUES ('$userid','$vvid','$from1','$to1','$rt','$date1','$time1','$no_of_seat','$amount')");
  if($sql)
  {

    ?>
    <script>
        alert("Inserted");
        </script>
        <?php
       // header("location:addtravel.php");
  }
else
{
  echo "error";
} 
  }
  ?>
  </body>
</html>