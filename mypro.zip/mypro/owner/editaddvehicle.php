<?php
include 'nav.php';
include 'connect.php';

  if(isset($_POST["Edit1"]))
  {
     $vid=$_POST['vid'];
    
      $qu2=mysqli_query($con,"select * from addvehicle where vid='$vid'");  
     $result=mysqli_fetch_array($qu2);

  
  
  
?>

<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">     
    $(document).ready(function() {
    $('#example').DataTable();
    } 
    );
    </script>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

  </head>
  <body>
    <br><center><h1><b>Add Vehicle Details</b></h1></center><br>
    <form name="profile" action="editaddvehicle.php" method="POST" enctype="multipart/form-data">

                        <div class="container">

                        <div class="row">

                        <div class="col">

                        <div class="mb-3">

                                <label  class="form-label">Model name</label><label style="color:red;"> *</label>

                                <input type="text" value="<?php echo $result['model_name']; ?>" class="form-control" id="modelname" name="modelname">

                                </div>

                        </div>

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Model Number</label><label style="color:red;"> *</label>

                                <input type="text" value="<?php echo $result['model_number']; ?>"  class="form-control" id="modelno" name="modelno">

                                </div>

                            </div>

                            </div>

                            <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label  class="form-label">Vehicle Number</label><label style="color:red;"> *</label>

                                <input type="text" class="form-control" id="Vehiclenumber" name="Vehiclenumber" value="<?php echo $result['vehicle_number']; ?>" >


                                </div>

                            </div>

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Build Year</label><label style="color:red;"> *</label>

                                <input type="text" class="form-control" id="buildyear" name="buildyear" value="<?php echo $result['Build_year']; ?>">

                                </div>

                            </div>

                            </div>
                            <div class="row">

                            <div class="col">

                                <div class="mb-3">

                                <label class="form-label">Fuel Type</label><label style="color:red;"> *</label>
                               <select class="form-select col-4" id="fueltype" name="fueltype" >

                                      <option value="<?php echo $result['Fueltype']; ?>"><?php echo $result['Fueltype']; ?></option>
                                       
                                        <option value="Petrol">Petrol</option>

                                        <option value="Diesel">Diesel</option>

                                        </select> 

                                </div>

                            </div>

                            <div class="col">

                                <label  class="form-label">Vehicle Type</label><label style="color:red;"> *</label>

                                <div class="container">

                                    <div class="row">

                                        <select class="form-select col-4" id="vehicletype" name="vehicletype" >
                                        <option value="<?php echo $result['Vehicle_type']; ?>"><?php echo $result['Vehicle_type']; ?></option>
                                        <option value="4Wheeler">4Wheeler</option>
                                        <option value="2Wheeler">2Wheeler</option>

                                        </select> 

                                    </div>

                                </div>       

                            </div>
 <div class="col">
                                <label  class="form-label">Picture</label><label style="color:red;"> *</label>
                                <div class="container">
                                    <div class="row">
                                       <img width='150px' height='150px' src='vehicleimg/<?php  echo $result['imgpath']; ?>'>
                                       <input type="file" class="form-control" value="<?php $result['imgpath']; ?>" id="picturepath" name="picturepath">
                                    </div>
                                </div>       
                            </div>
                        </div>
                        <input type="hidden" value="<?php echo $vid; ?>" name="vvid">

                            <center><div class="col-12">
                                <button type="submit" name="smtuppvehicle" class="btn btn-primary col-2">UPDATE</button>
                            </div></center>
                            
                    </form>


<?php
  }
include("connect.php");

  if(isset($_POST["smtuppvehicle"]))
  {

      $userid=$_SESSION['uid'];
      $vvid=$_POST["vvid"];
    
      $modelname=$_POST["modelname"];
      $modelno=$_POST["modelno"];
    $vehicleno=$_POST["Vehiclenumber"];
    $buildyear=$_POST["buildyear"];
    $fueltype=$_POST["fueltype"];
    $vehicletype=$_POST["vehicletype"];
    
   
 
 $msg="";
 $imgpath=$_FILES["picturepath"]["name"];

// check if the user has clicked the button "UPLOAD" 

    $filename = $_FILES["picturepath"]["name"];

    $tempname = $_FILES["picturepath"]["tmp_name"];  


        $folder = "vehicleimg/".$filename;   
      if (move_uploaded_file($tempname, $folder)) {

            $msg = "Image uploaded successfully";

        }else{

           $imgpath="user.png";
    }
    $sql=mysqli_query($con,"UPDATE addvehicle SET 
    uid='$userid',
    model_name='$modelname',
    model_number='$modelno',
    vehicle_number='$vehicleno',
    Build_year='$buildyear',
    Fueltype='$fueltype',
    Vehicle_type='$vehicletype',
    imgpath='$imgpath' 
    where 
    vid='$vvid'");
      

  if($sql)
  {
    ?>
    <script>
        alert("updated");
        </script>
        <?php
        header("location:addvehicle.php");
  }
else
{
  echo "error";
} 
  }
  ?>
  </body>
</html>