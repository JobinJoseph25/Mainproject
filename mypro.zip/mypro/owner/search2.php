<?php
include "connect.php";
 
if(isset($_POST["query"]))  
{  
      $output = '';  
      $query = "SELECT * FROM tbl_place WHERE places LIKE '%".$_POST["query"]."%'";  
      $result = mysqli_query($con, $query);  
      $output = '<ul class="list-unstyled">';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '<li>'.$row["routs"].'</li>';  
           }  
      }  
      else  
      {  
           $output .= '<li>Country Not Found</li>';  
      }  
      $output .= '</ul>';  
      echo $output;  
    }







    
 ?>