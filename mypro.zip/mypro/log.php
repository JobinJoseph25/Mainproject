<?php
include('nav1.php');

?>

<html>
<head>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

        <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        .gradient-custom-2 {
/* fallback for old browsers */
background: #fccb90;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, #ee7724, #d8363a, #dd3675, #b44593);

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, #ee7724, #d8363a, #dd3675, #b44593);
}

@media (min-width: 768px) {
.gradient-form {
height: 100vh !important;
}
}
@media (min-width: 769px) {
.gradient-custom-2 {
border-top-right-radius: .3rem;
border-bottom-right-radius: .3rem;
}
}
    </style>
</head>
<body>
<section class="h-100 gradient-form" style="background-color: #eee;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-xl-10">
        <div class="card rounded-3 text-black">
          <div class="row g-0">
            <div class="col-lg-6">
              <div class="card-body p-md-5 mx-md-4">

                <div class="text-center">
                  <img src="loginlogo.png"
                    style="width: 185px;" alt="logo">
                  <h4 class="mt-1 mb-5 pb-1">Log in</h4>
                </div>

                
                  <p>Please login to your account</p>
           <form action="#" method="POST" enctype="multipart/form-data">
                  <div class="form-outline mb-4">
                    <input type="email" id="name" class="form-control"
                      placeholder="enter email address" name="email" />
                    <label class="form-label" for="form2Example11">Username</label>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" id="pass" class="form-control" name="passwd" />
                    <label class="form-label" for="form2Example22">Password</label>
                  </div>
                 <div class="text-center pt-1 mb-5 pb-1">
                    <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3"  id="submit1"  type="submit" name="btnlogin">Log
                      in</button>
                    </form>
                    <a class="text-muted" href="Resetpassword\index.php">Forgot password?</a>
                  </div>
                  <div class="d-flex align-items-center justify-content-center pb-4">
                    <p class="mb-0 me-2">Don't have an account?</p>
                   <a href="reg.php"> <button type="button"  class="btn btn-outline-danger">Create new</button></a>
                  </div>
                
              </div>
            </div>
            <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
              <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                <h4 class="mb-4">We are more than just a company</h4>
                <p class="small mb-0">
                  The vehicle Sharing system is a web-based application to provide us with a simple 
                  riding platform between the vehicle owner and a user. The vehicle owner can post a travel destination 
                  prior to the travel date and if anyone is interested to travel in the same location, he/she can contact 
                  the vehicle owner and book the ride with an amount specified by the owner. Personal ride booking and sharing 
                  services allow customers to arrange transportation quickly and at a reasonable amount. This application typically 
                  matches a customers location with the nearest available vehicle. This project consists of a website and its mobile application.
       This website keeps the data in a centralized way which is available to all the users at the same time.
       This system is an effort to reduce consumption of fuel, our most important non-renewable resource and traffic congestion
       on roads by encouraging people to use Vehicle sharing. So it is an environment-friendly social application and also helps
       people to reduce their journey time.
      </p>


      </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section></body>
</html>
<?php
include("connect.php");

  if(isset($_POST["btnlogin"])){

  
      $uname=$_POST["email"];
      $pass=$_POST["passwd"];
  
      $sql="select * from registration where email='$uname' && password='$pass'";

      $result=mysqli_query($con,$sql);
       
       if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
       $_SESSION['uid']= $row["id"];
        $_SESSION['nnm']= $row["name"];
        $_SESSION['prof']= $row["path"];
       $st= $row["Statuss"];
         $typ=$row["usertype"];
        

            }}


      $count=mysqli_num_rows($result);
      
      if($count>0)
      { 
        if($st==0)
        {
          if($typ=="Vehicle_Owner")
          {
            
               echo "<script>window.location.href='owner/Home.php';</script>";
            
          }
          else if($typ=="Vehicle_User")
          {
            echo "<script>window.location.href='users/usrhome.php';</script>";
        
          
          }
        }
        else{
          ?>
        <script>
        alert("You were blocked by Admin");
        </script>
        <?php
      }
  
      }
      else
      {
        ?>
        <script>
        alert("invalid username or password");
        </script>
        <?php
      }
  }
?>

