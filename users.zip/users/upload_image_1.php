<?php 
include("navuser.php");
include("connect.php");
$uiid=$_SESSION['uid'];
$e = '';


if (isset($_GET["error"])) {
    $e = $_GET["error"];
    if ($e == "2") {
        $e = "<div class='alert alert-danger text-center alert-dismissible'>
                
                <h5> Size Too Large,Image size should be less than 1mb.</h5>
            </div>";
    } elseif ($e == "3") {
        $e = "<div class='alert alert-danger text-center alert-dismissible'>
                
                <h5>File Type Not Supported...</h5>
            </div>";
    } elseif ($e == "1") {
        $e = "<div class='alert alert-danger text-center alert-dismissible'>
                
                <h5>Unknown Error Occurred...</h5>
            </div>";
    } else {
        $e = "";
    }
}

?>
<html>
    <title>editprofile</title>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<center>
<div class="row">
    <div class="col-xl-4">
        <div class="card mb-4 mb-xl-0">
            <div class="card-header">Profile Picture</div>
                <div class="card-body text-center">
                    <!-- <img class="img-account-profile rounded-circle mb-2" src="..\owner/propic/<?php echo $ii; ?>" alt=""/> -->
                    <div class="small font-italic text-muted mb-4">
                        JPG or PNG no larger than 5 MB
                    </div>
                    <form name="upload2" method="post" action="new_image.php" enctype="multipart/form-data" style="margin: 50px;">

                    <?php
                    echo $e;
                    ?>

                    <div class="mb-4">
                        <center>

                            <?php

                            $fetchimage = "SELECT * FROM registration where id = $uiid";
                            $fetchimageresult = mysqli_query($con, $fetchimage);
                            while ($fetchimageresultdata = mysqli_fetch_assoc($fetchimageresult)) {
                                 $name = $fetchimageresultdata["path"];
                            ?>
                                
                                <img class="img-thumbnail rounded" src="..\owner/propic/<?php echo $name; ?>" style="width: 200px;height: 200px;"  alt="Error" />
                                
                            <?php
                            }
                            ?>
                            <input class="form-control" type="file" name="image2" style="width: 200px;" required />
                        </center>
                    </div>

                    <center>
                        <input type="submit" name="submit3" class="btn btn-outline-primary" />
                    </center>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
</center>