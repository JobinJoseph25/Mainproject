<?php
include 'navuser.php';

include 'connect.php';
if(isset($_POST['joinbtwn']))
{
?>
<!DOCTYPE html>
<html>
<head>
	<style>

.btn1 {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
th {
  text-align: left;
}
h1{
	color: black;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">   
    
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <script>
      function submit()
      {
        form.submit();
      }
          </script>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
<style>
    .container {
  padding: 10px;
}

ul li {
  list-style: none;
}
th{
  margin:10px;
  padding:10px;

}
</style>

</head>
<body style="background: url(bookin.jpg);
  background-repeat: no-repeat;
  background-size: 1600px;">
	<title >Booking</title>
	


  
<div class="container">
<?php
    $w=$_POST['tvlllid'];
    

                    $query2=mysqli_query($con,"select * from addtraveldetails,addvehicle,registration where (addtraveldetails.t_uid=(addvehicle.uid & registration.id)) & (addtraveldetails.tvlid='$w') &
                    (addvehicle.vid=addtraveldetails.t_vid)");  
    while($result=mysqli_fetch_array($query2))
  { 
 //  echo $result;
  ?>
  
  <form action="" method="POST" enctype="multipart/form-data">
  
  <div class="row" id="myItems">
    <div class="col-sm-9 mb-3">
    <center><h1 style="color: green;">Travel Details</h1>
  <br> <img  src="..\owner/vehicleimg/<?php echo $result['imgpath']; ?>" alt="Card image cap" style="height:150px">
  <h5 class="card-subtitle mb-2 text-muted">Vehicle name: <?php echo $result['model_name']; ?></h5></th>
  </center>
       <table class="card">   
       

  <tr> 
  <input type="hidden" name="ownerid" value="<?php echo $result['id']; ?>">
  <input type="hidden" name="tvlllid" value="<?php echo $result['tvlid']; ?>">

  <input type="hidden" name="frm" value="<?php echo $result['froms']; ?>">
  
  <input type="hidden" name="tto" value="<?php echo $result['tos']; ?>">
  <input type="hidden" name="rrouts" value="<?php echo $result['routs']; ?>">
  <input type="hidden" name="ttlseats" value="<?php echo $result['no_of_seats']; ?>">
  <input type="hidden" name="ddates" value="<?php echo $result['dates']; ?>">
  <input type="hidden" name="ttime" value="<?php echo $result['times']; ?>">
  <input type="hidden" name="aamount" value="<?php echo $result['amount']; ?>">
  <input type="hidden" name="ownername" value="<?php echo $result['name']; ?>">
  <input type="hidden" name="onemail" value="<?php echo $result['email']; ?>">
  <input type="hidden" name="onephone" value="<?php echo $result['phone']; ?>">
  <input type="hidden" name="oneplace" value="<?php echo $result['place']; ?>">




  <th><h5 class="card-subtitle mb-2 text-muted">From: <?php echo $result['froms']; ?></h5></th>
          
          <th><h5 class="card-subtitle mb-2 text-muted">To: <?php echo $result['tos']; ?></h5></th>
          <th><h5 class="card-subtitle mb-2 text-muted">Date: <?php echo $result['dates']; ?></h5></th>
          
          <th><h5 class="card-subtitle mb-2 text-muted">No_oF_seats: <?php echo $result['no_of_seats']; ?></h5></th>
 
  </tr>
  <tr> 
  <th><h5 class="card-subtitle mb-2 text-muted">Type: <?php echo $result['Vehicle_type']; ?></h5></th>
  <th><h5 class="card-subtitle mb-2 text-muted">Fuel Type: <?php echo $result['Fueltype']; ?></h5></th>
      
      <th><h5 class="card-subtitle mb-2 text-muted">Time :<?php echo $result['times']; ?></h5></th>
      <th><h5 class="card-subtitle mb-2 text-muted">Amount: <?php echo $result['amount']; ?></h5></th>
 
  </tr>
  <tr>
<th colspan="10"><h5 class="card-subtitle mb-2 text-muted">Travel Routs: <?php echo $result['routs']; ?></h5></th>
      
  </tr>
 
  </table>   
  
  <center><h1 style="color: green;">Owner Details</h1>
  <img  src="..\owner/propic/<?php echo $result['path']; ?>" alt="Card image cap" style="border-radius: 100%;width:70px;">
  <h5 class="card-subtitle mb-2 text-muted"><?php echo $result['name']; ?></h5>
  </center>
  <table class="card">   
       

  <tr> 
  

  <th><h5 class="card-subtitle mb-2 text-muted">Username: <?php echo $result['username']; ?></h5></th>
          
          <th><h5 class="card-subtitle mb-2 text-muted">Email: <?php echo $result['email']; ?></h5></th>
          <th><h5 class="card-subtitle mb-2 text-muted">Phone: <?php echo $result['phone']; ?></h5></th>
          
         
 
  </tr>
  <tr> 
  <th><h5 class="card-subtitle mb-2 text-muted">Place: <?php echo $result['place']; ?></h5></th>
  <th><h5 class="card-subtitle mb-2 text-muted">State: <?php echo $result['state']; ?></h5></th>
      
      <th><h5 class="card-subtitle mb-2 text-muted">Country :<?php echo $result['country']; ?></h5></th>
      
 
  </tr>
       </table>   <center>     
       <table class="card">   
       
       <tr> 

 
<th><h5 class="card-subtitle mb-2 text-muted">Upolad proof: <input type="file" name="profs" accept="application/pdf,application/vnd.ms-excel" required> </h5>
<h5 style="color: red;">**Proof must be the orginal copy of any government id proof. </h5>
<h5 style="color: red;">scan and upload the proof including co-passengers</h5>
<h5 style="color: red;">(if there are more than 1 passenger then scan and combine the proof one by one)**</h5></th>   
</tr>

       <tr> 
       
      
       <th><label>select no of seats</label>
       <input name="nosts" type="number" id=""
    value="<?php echo $result['no_of_seats']; ?>" min="1" max="<?php echo $result['no_of_seats']; ?>" pattern="[0-9]*"
    data-quantity-item="{{ forloop.index }}">
       </th>
       <th>Type a pickup Destination: <input type="text" name="txtpick" class="col-12" required>
  </th>
  <th>
       Price: <input type="text" name="txtprice" class="col-9" required>
      
      </th>
              
     <th>  <button type="submit" name="bktn" class="btn btn-primary col-12">Request Joining!</button></th>

     <?php   
  }
}       
?><th>  
  
</form>
            </table> </center>
       
  </div>
</div>


</div>

                  
</body>

</html>
<?php
include("connect.php");

  if(isset($_POST["bktn"]))
  {
    $ownerid=$_POST['ownerid'];
    $usrid=$_SESSION['uid'];
    $tvlid=$_POST['tvlllid'];
    $froms=$_POST['frm'];
    $to=$_POST['tto'];
    $routs=$_POST['rrouts'];
    $noseats=$_POST['ttlseats'];
    $ddates=$_POST['ddates'];
    $ttime=$_POST['ttime'];
    $aamount=$_POST['aamount'];
    $ownername=$_POST['ownername'];
    $onemail=$_POST['onemail'];
    $onephone=$_POST['onephone'];
    $oneplace=$_POST['oneplace'];
    //$ttlseatss=$_POST['ttlseats'];
    $nns=$_POST['nosts'];
   //$ll=$ttlseatss-$nns;
  $pickupdest=$_POST['txtpick'];
  $price=$_POST['txtprice'];
    
 $msg="";
 $imgpath=$_FILES["profs"]["name"];

// check if the user has clicked the button "UPLOAD" 

    $filename = $_FILES["profs"]["name"];

    $tempname = $_FILES["profs"]["tmp_name"];  


        $folder = "..\proof/".$filename;   
      if (move_uploaded_file($tempname, $folder)) {

            $msg = "Image uploaded successfully";

        }else{

           $imgpath="user.png";
    }
    
    $sql="INSERT INTO `vhlbooking`(`ownerid`, `userid`, `travelid`, `frm`, `ttoo`, `rrouts`,`pickupdest`, `ttlseat`,
     `ddate`, `ttime`, `aamount`,`sseatsneeded`, `owner_name`, `owner_email`, `owner_phone`, `owner_place`, `paymentstat`,
     `proof`, `bkstatus`)
     VALUES ('$ownerid','$usrid','$tvlid','$froms','$to','$routs','$pickupdest','$noseats','$ddates','$ttime',
     '$price','$nns','$ownername','$onemail','$onephone','$oneplace','unpaid','$imgpath','processing')";
  if(mysqli_query($con,$sql))
  {
   // $jj=mysqli_query($con,"UPDATE `addtraveldetails` SET `no_of_seats`='$ll' WHERE tvlid='$tvlid'");
    ?>
    <script>
        alert("inserted");
    </script>
    <?php
  }
  else
  {
    echo "error";
  }
  
    }
  ?>
