<?php
include 'navuser.php';

include 'connect.php';

  if(isset($_POST["btn2"]))
  {
     $srch=$_POST['srchresult'];
     ?>
     <script>
      
        form.submit();
      
          </script>
     <?Php

  }
?>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">   
    
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <script>
      function submit()
      {
        form.submit();
      }
          </script>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
<style>
    .container {
  padding: 10px;
}

ul li {
  list-style: none;
}
th{
  margin:10px;
  padding:10px;

}
</style>
  </head>
  <body>
    <br><center><h1><b>Search Vehicle</b></h1></center><br> 
    <div class="container">  <form action="" method="GET" name="formfs">
  <div class="row">
 
      <table class="col"><tr><th><input type="text" name="search" id="myFilter" class="form-control"  
      value="<?php if(isset($_GET['search'])){echo $_GET['search'];}else if(isset($_POST['btn2'])){echo $_POST['srchresult'];}?>">
    </th><th><button class="btn btn-success" type="submit" style="padding:15px;">search</button></th></tr>
  </table>
</form>
  </div>
  
  
<?php
if(isset($_GET['search'])||isset($_POST['srchresult']))
{


  if(isset($_GET['search'])){
    $filtervalues=$_GET['search'];
  }
  if(isset($_POST['srchresult'])){
    $filtervalues=$_POST['srchresult'];
  }
  // $query2=mysqli_query($con,"select * from addtraveldetails,addvehicle,registration where
  // (addtraveldetails.t_uid=(addvehicle.uid & registration.id)) & (addtraveldetails.t_vid=addvehicle.vid) & 
  // (concat(addtraveldetails.froms,addtraveldetails.tos,addtraveldetails.routs) LIKE '%$filtervalues%');");  
  $query2=mysqli_query($con," select * from addtraveldetails,addvehicle,registration where
  (addtraveldetails.t_uid=addvehicle.uid AND addtraveldetails.t_uid=registration.id) AND (addtraveldetails.t_vid=addvehicle.vid) AND 
  (concat(addtraveldetails.froms,addtraveldetails.tos,addtraveldetails.routs) LIKE '%$filtervalues%');");
 
    while($result=mysqli_fetch_array($query2))
  { 
 //echo $result;
  ?>
  <form action="viewtraveldetails.php" method="POST" name="k">
  <div class="row" id="myItems">
    <div class="col-sm-9 mb-3">
     <input type="hidden" name="ttvlid" value="<?php echo $result['tvlid']; ?>">
       <table class="card">   
      

  <tr> 
  <th><img class="card-img-top" src="..\owner/vehicleimg/<?php echo $result['imgpath']; ?>" alt="Card image cap" style="height:150px"></th>
  <th><img class="card-img-top" src="..\owner/propic/<?php echo $result['path']; ?>" alt="Card image cap" style="border-radius: 100%;width:70px;">
  <h5 class="card-subtitle mb-2 text-muted"><?php echo $result['name']; ?></h5></th>
           
          <th> <h5 style="border-radius: 100%;width:70px;"></h5>
            <h5 class="card-subtitle mb-2 text-muted">Vehicle name: <?php echo $result['model_name']; ?></h5></th>
        <th rowspan="5"><button type="submit" name="smtupp" class="btn btn-danger col-40">View</button></th>
  </tr><tr>
          <th><h5 class="card-subtitle mb-2 text-muted">From: <?php echo $result['froms']; ?></h5></th>
          
          <th><h5 class="card-subtitle mb-2 text-muted">To: <?php echo $result['tos']; ?></h5></th>
          
          <th><h5 class="card-subtitle mb-2 text-muted">No_oF_seats: <?php echo $result['no_of_seats']; ?></h5></th>
       

</tr>
<tr> 
<th><h5 class="card-subtitle mb-2 text-muted">Date: <?php echo $result['dates']; ?></h5></th>
      
          <th><h5 class="card-subtitle mb-2 text-muted">Time :<?php echo $result['times']; ?></h5></th>
          <th><h5 class="card-subtitle mb-2 text-muted">Amount: <?php echo $result['amount']; ?></h5></th>

</tr>

<tr>
<th colspan="10"><h5 class="card-subtitle mb-2 text-muted">Travel Routs: <?php echo $result['routs']; ?></h5></th>
      
  </tr>
  </table>   
  </div>
</div></form>
<?php   
   }
  
  }
  else{
    echo "No Records found!!";
  }
?>
</div>

  </body>
</html>

