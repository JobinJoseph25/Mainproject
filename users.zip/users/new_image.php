<?php
session_start();
if (isset($_POST['submit3'])) {



    echo "second";



    // include("db_connection.php");
    include("connect.php");
   

    $img_name1 = $_FILES['image2']['name'];
    $img_size1 = $_FILES['image2']['size'];
    $tep_name1 = $_FILES['image2']['tmp_name'];
    $error1 = $_FILES['image2']['error'];
    $img_type1 = $_FILES['image2']['type'];

    
    if ($error1 === 0) {
        if ($img_size1 > 1250000) {

            $em2 = "2";
            header('Location: upload_image_1.php?error=' . $em2);
        } else {
           
            $img_extension1 = pathinfo($img_name1, PATHINFO_EXTENSION);
            
            $img_extension_low1 = strtolower($img_extension1);
            

            $allowed_extensions = array("jpeg", "jpg", "png", "gif");

            if (in_array($img_extension_low1, $allowed_extensions)) {
                
                $new_image_name1 = uniqid("IMG-", true) . '.' . $img_extension_low1;
                


                
                $img_upload_path1 = '..\owner/propic/' . $new_image_name1;
                
                echo 'hello';



               

                $id = $_SESSION['uid'];
                echo $id;
                $imageqeury = "UPDATE registration SET path ='$new_image_name1' WHERE id = $id ";

                $imageresult = mysqli_query($con, $imageqeury);
                if ($imageresult) {
                    echo $_SESSION['uid'];
                    move_uploaded_file($tep_name1, $img_upload_path1);
                    
                    header('Location: upload_image_1.php?id=' . $id);
                }
            } else {
                $em1 = "3";
                header('Location: upload_image_1.php?error=' . $em1);
            }
        }
    } else {
        $em = "1";
        header('Location: upload_image_1.php?error= ' . $em);
    }
} else {
    header('Location: upload_image_1.php');
}

