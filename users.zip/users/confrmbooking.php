
<?php
include 'navuser.php';
include 'connect.php';
?>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">     
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
<style>
  
    </style>
  </head>

<body >

<div class="card text-center">
  <div class="card-header">
    Confirm Booking
  </div>
  <div class="card-body">


<?php
    $w=$_POST['tvlllid'];
    $ownerid=$_POST['ownerid'];
    $usrid=$_SESSION['uid'];
    $tvlid=$_POST['tvlllid'];
    $froms=$_POST['frm'];
    $to=$_POST['tto'];
    $routs=$_POST['rrouts'];
    $noseats=$_POST['ttlseats'];
    $ddates=$_POST['ddates'];
    $ttime=$_POST['ttime'];
    $aamount=$_POST['aamount'];
    $ownername=$_POST['ownername'];
    $onemail=$_POST['onemail'];
    $onephone=$_POST['onephone'];
    $oneplace=$_POST['oneplace'];
    
    

   
  $query2=mysqli_query($con,"select * from addtraveldetails,addvehicle,registration where (addtraveldetails.t_uid=(addvehicle.uid & registration.id)) & (addtraveldetails.tvlid='$w') &
                    (addvehicle.vid=addtraveldetails.t_vid)");  
    while($result=mysqli_fetch_array($query2))
  { 
 //echo $result;
  ?>

    <center>
  <br> <img  src="..\owner/vehicleimg/<?php echo $result['imgpath']; ?>" alt="Card image cap" style="height:150px">
  <h5 class="card-subtitle mb-2 text-muted">Vehicle name: <?php echo $result['model_name']; ?></h5></th>
  
       <table>   
       

  <tr> 

  <th><h5 class="card-subtitle mb-2 text-muted">From: <?php echo $result['froms']; ?></h5></th>
          
          <th><h5 class="card-subtitle mb-2 text-muted">To: <?php echo $result['tos']; ?></h5></th>
         
          
  </tr>
  
  <tr> 

  <th><h5 class="card-subtitle mb-2 text-muted">Routs: <?php echo $result['routs']; ?></h5></th>
         
  </tr>

  <tr> 

 
  <th><h5 class="card-subtitle mb-2 text-muted">Total seats: <?php echo $result['no_of_seats']; ?></h5></th>
  
         
  </tr>
  <form action="" method="POST" enctype="multipart/form-data">
  <tr>
  <th><h5 class="card-subtitle mb-2 text-muted">Select seats:
 <input name="nosts" type="number" id=""
    value="<?php echo $result['no_of_seats']; ?>" min="1" max="<?php echo $result['no_of_seats']; ?>" pattern="[0-9]*"
    data-quantity-item="{{ forloop.index }}"></h5>
</th>      
  </tr>

  <tr> 

 
<th><h5 class="card-subtitle mb-2 text-muted">Rate: <?php echo $result['amount']; ?>/seats<label id = "GFG">
     
   </h5></th>

       
</tr>
<tr> 

 
<th><h5 class="card-subtitle mb-2 text-muted">Upolad proof: <input type="file" name="profs" accept="application/pdf,application/vnd.ms-excel" required> </h5>
<h5 style="color: red;">**Proof must be the orginal copy of any government id proof. </h5>
<h5 style="color: red;">scan and upload the proof including co-passengers</h5>
<h5 style="color: red;">(if there are more than 1 passenger then scan and combine the proof one by one)**</h5></th>   
</tr>

  </table><br>

  </center>






  
  <input type="hidden" name="ownerid" value="<?php echo $ownerid; ?>">
    <input type="hidden" name="tvlllid" value="<?php echo $tvlid; ?>">
  
    <input type="hidden" name="frm" value="<?php echo $froms; ?>">
    
    <input type="hidden" name="tto" value="<?php echo $to; ?>">
    <input type="hidden" name="rrouts" value="<?php echo $routs; ?>">
    <input type="hidden" name="ttlseats" value="<?php echo $noseats; ?>">
    <input type="hidden" name="ddates" value="<?php echo $ddates; ?>">
    <input type="hidden" name="ttime" value="<?php echo $ttime; ?>">
    <input type="hidden" name="aamount" value="<?php echo $aamount; ?>">
    <input type="hidden" name="ownername" value="<?php echo $ownername; ?>">
    <input type="hidden" name="onemail" value="<?php echo $onemail; ?>">
    <input type="hidden" name="onephone" value="<?php echo $onephone; ?>">
    <input type="hidden" name="oneplace" value="<?php echo $oneplace; ?>">
    <input type="submit" name="smttipp" class="btn btn-danger" value="Book Now">
  </form>
    <?php
  }
    ?>
  </div>
  <div class="card-footer text-muted">
    Book now and Enjoy the ride!!!!! 
  </div>
</div>
</body>
</html> 
<?php
include("connect.php");

  if(isset($_POST["smttipp"]))
  {
    //$ttlseatss=$_POST['ttlseats'];
    $nns=$_POST['nosts'];
   //$ll=$ttlseatss-$nns;
  
    
 $msg="";
 $imgpath=$_FILES["profs"]["name"];

// check if the user has clicked the button "UPLOAD" 

    $filename = $_FILES["profs"]["name"];

    $tempname = $_FILES["profs"]["tmp_name"];  


        $folder = "..\proof/".$filename;   
      if (move_uploaded_file($tempname, $folder)) {

            $msg = "Image uploaded successfully";

        }else{

           $imgpath="user.png";
    }
    
    $sql="INSERT INTO `vhlbooking`(`ownerid`, `userid`, `travelid`, `frm`, `ttoo`, `rrouts`,`pickupdest`, `ttlseat`, `ddate`, `ttime`, `aamount`, 
    `sseatsneeded`, `owner_name`, `owner_email`, `owner_phone`, `owner_place`, `paymentstat`,`proof`, `bkstatus`)
     VALUES ('$ownerid','$usrid','$tvlid','$froms','$to','$routs','$froms','$noseats','$ddates','$ttime',
     '$aamount','$nns','$ownername','$onemail','$onephone','$oneplace','unpaid','$imgpath','processing')";
  if(mysqli_query($con,$sql))
  {
   // $jj=mysqli_query($con,"UPDATE `addtraveldetails` SET `no_of_seats`='$ll' WHERE tvlid='$tvlid'");
    ?>
    <script>
        alert("inserted");
    </script>
    <?php
  }
  else
  {
    echo "error";
  }
  
    }
  ?>
