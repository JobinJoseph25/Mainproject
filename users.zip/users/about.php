
<?php
include 'navuser.php';

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body>

<div class="about-section">
  <h1>About Us</h1>
  <p>The vehicle Sharing system is a web-based application to provide us with a simple riding platform between the vehicle owner and a user. The vehicle owner can post a travel destination prior to the travel date and if anyone is interested to travel in the same location, he/she can contact the vehicle owner and book the ride with an amount specified by the owner. Personal ride booking and sharing services allow customers to arrange transportation quickly and at a reasonable amount. This application typically matches a customer’s location with the nearest available vehicle. This project consists of a website and its mobile application. This website keeps the data in a centralized way which is available to all the users at the same time.</p>
  <p>This system is an effort to reduce consumption of fuel, our most important non-renewable resource and traffic congestion on roads by encouraging people to use Vehicle sharing. So it is an environment-friendly social application and also helps people to reduce their journey time.</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="pic.jpg" alt="jobin" style="width:20%;height:20%">
      <div class="container">
        <h2>Jobin Joseph</h2>
        <p class="title">CEO & Founder</p>
        <p>jobin@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="propic/s1.png" alt="Mike" style="width:20%;height:20%">
      <div class="container">
        <h2>Mike Ross</h2>
        <p class="title">Art Director</p>
     
        <p>mike@example.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="propic/s2.png" alt="John" style="width:20%;height:20%">
      <div class="container">
        <h2>John Doe</h2>
        <p class="title">Designer</p>
       
        <p>john@example.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>
