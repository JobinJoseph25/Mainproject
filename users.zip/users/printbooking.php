
<?php 
session_start();

include('connect.php');
include('pdf_mc_table.php');

$usid=$_SESSION['uid'];
$tvid=$_POST['tvlsids'];
  $result = mysqli_query($con,"select * from vhlbooking where userid='$usid' AND travelid='$tvid'");
  $pdf = new PDF_MC_TABLE();
  $pdf->AddPage();
  $pdf->SetFont('Arial', 'B', 15);
  $pdf->Cell(176, 5, 'Booking Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();
  $pdf->SetFont('Arial','',10);
  $pdf->SetWidths(Array(11,20,25,30,20,20,20,30,30,30,30));
  // $pdf->SetLineHeight(5);
  // $pdf->SetFont('Arial','B',10);
  // $pdf->Cell(11,5,"Sl No",1,0);
  // $pdf->Cell(20,5,"From",1,0);
  // $pdf->Cell(25,5,"To",1,0);
  // $pdf->Cell(30,5,"Routs",1,0);
  // $pdf->Cell(20,5,"Pick Up Destination",1,0);
  // $pdf->Cell(20,5,"Owner name",1,0);
  // $pdf->Cell(20,5,"Username",1,0);
  // $pdf->Cell(20,5,"Total Seats",1,0);
  // $pdf->Cell(20,5,"Date",1,0);
  // $pdf->Cell(20,5,"Time",1,0);
  // $pdf->Cell(20,5,"Total Amount",1,0);
  // $pdf->Cell(20,5,"payment status",1,0);
  $pdf->Ln();
  // $pdf->SetFont('Arial','',10);	
 
  foreach($result as $row) {
    $pdf->Row(Array(
       
		// $row['frm'],
		// $row['ttoo'],
		// $row['rrouts'],
		// $row['ddate'],
		// $row['pickupdest'],
		// $row['owner_name'],
    $pdf->Multicell(0,12,'From : '. $row['frm'] ,1,'C'),
    $pdf->Multicell(0,12,'To : '. $row['ttoo'] ,1,'C'),
    $pdf->Multicell(0,12,'Routs : '. $row['rrouts'] ,1,'C'),
    $pdf->Multicell(0,12,'Pick Up Destination : '. $row['pickupdest'] ,1,'C'),
    $pdf->Multicell(0,12,'Owner name : '. $row['owner_name'] ,1,'C'),
    $pdf->Multicell(0,12,'Username : '. $row['userid'] ,1,'C'),
    $pdf->Multicell(0,12,'Total Seats : '. $row['sseatsneeded'] ,1,'C'),
    $pdf->Multicell(0,12,'Date : '. $row['ddate'] ,1,'C'),
 
    $pdf->Multicell(0,12,'Time : '. $row['ttime'] ,1,'C'),
    $pdf->Multicell(0,12,'Amount : '. $row['aamount'] ,1,'C'),
   
    $pdf->Multicell(0,12,'Payment Status : '. $row['paymentstat'] ,1,'C'),
    // $pdf->Multicell(0,12,'Status : '. $status ,1,'C');
    // $row['userid'],
    // $row['sseatsneeded'],
    // $row['ddate'],
    // $row['ttime'],
    // $row['aamount'],
    // $row['paymentstat'],
	));

  }
  $pdf->Output();

?>
