<?php
include("connect.php");
$usrid = $_GET['usrid'];
$ownrid = $_GET['ownrid'];

$trvllid = $_GET['trvllid'];
$t=$_GET['ttlamount'];
if(mysqli_query($con,"INSERT INTO tbl_payment(p_userid,p_ownerid,p_tvlid,p_amount) VALUES ('$usrid','$ownrid','$trvllid','$t')"))
{
    $w=mysqli_query($con,"UPDATE `vhlbooking` SET `paymentstat`='Paid'");
    header("location:usrtrack.php");
}

?>