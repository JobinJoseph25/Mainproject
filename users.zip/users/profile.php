
<?php 
include("navuser.php");
include("connect.php");
$uiid=$_SESSION['uid'];

?>
<html>
    <title>editprofile</title>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    <style>

.img-account-profile {
    height: 10rem;
}
.rounded-circle {
    border-radius: 50% !important;
}
.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgb(33 40 50 / 15%);
}
.card .card-header {
    font-weight: 500;
}
.card-header:first-child {
    border-radius: 0.35rem 0.35rem 0 0;
}
.card-header {
    padding: 1rem 1.35rem;
    margin-bottom: 0;
    background-color: rgba(33, 40, 50, 0.03);
    border-bottom: 1px solid rgba(33, 40, 50, 0.125);
}
.form-control, .dataTable-input {
    display: block;
    width: 100%;
    padding: 0.875rem 1.125rem;
    font-size: 0.875rem;
    font-weight: 400;
    line-height: 1;
    color: #69707a;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #c5ccd6;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0.35rem;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.nav-borders .nav-link.active {
    color: #0061f2;
    border-bottom-color: #0061f2;
}
.nav-borders .nav-link {
    color: #69707a;
    border-bottom-width: 0.125rem;
    border-bottom-style: solid;
    border-bottom-color: transparent;
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
    padding-left: 0;
    padding-right: 0;
    margin-left: 1rem;
    margin-right: 1rem;
}
    </style>    
    <head>
<?php 
include("connect.php");
$uiid=$_SESSION['uid'];
$qu2=mysqli_query($con,"select * from registration where id='$uiid'");  
$result1=mysqli_fetch_array($qu2);


?>
    <div class="container-xl px-4 mt-4">
    <!-- Account page navigation-->
   
    <hr class="mt-0 mb-4">
    <div class="row">
        <div class="col-xl-4">
            <!-- Profile picture card-->
            <div class="card mb-4 mb-xl-0">
                <div class="card-header">Profile Picture</div>
                <div class="card-body text-center">
                    <!-- Profile picture image-->
                    <img class="img-account-profile rounded-circle mb-2" style="width:200px;height:200px" src="..\owner/propic/<?php echo $ii; ?>" alt="">
                    <!-- Profile picture help block-->
                    <div class="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB</div>
                    <!-- Profile picture upload button-->
                    <form action="upload_image_1.php" method="post">
                        <input type="submit" class="btn btn-primary" value="Upload new image"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-8">
            <!-- Account details card-->
            <div class="card mb-4">
                <div class="card-header">Edit Profile Details</div>
                <div class="card-body">
                    <form action="" method="POST">
                        <!-- Form Group (username)-->
                        <div class="mb-3">
                            <label class="small mb-1" for="inputUsername">Fullname (how your name will appear to other users on the site)</label>
                            <input class="form-control" id="inputUsername" type="text" name='fname' placeholder="Enter your full name" value="<?php echo $result1['name']; ?>" required>
                        </div>
                        <!-- Form Row-->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (first name)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputFirstName">Username</label>
                                <input class="form-control" id="inputFirstName" type="text" name="uname" placeholder="Enter your username" value="<?php echo $result1['username']; ?>" required>
                            </div>
                            <!-- Form Group (last name)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputLastName">Email</label>
                                <input class="form-control" id="inputLastName" name="emails" type="text" placeholder="Enter your email" value="<?php echo $result1['email']; ?>" required>
                            </div>
                        </div>
                        <!-- Form Row        -->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (organization name)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputOrgName">Phone</label>
                                <input class="form-control" id="inputOrgName" type="text" name="phoneno" placeholder="Enter your Phone no" value="<?php echo $result1['phone']; ?>" required>
                            </div>
                            <!-- Form Group (location)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputLocation">Place</label>
                                <input class="form-control" id="inputLocation" name="place" type="text" placeholder="Enter your location" value="<?php echo $result1['place']; ?>" required>
                            </div>
                        </div>
                        <!-- Form Group (email address)-->
                        <div class="mb-3">
                            <label class="small mb-1" for="inputEmailAddress">State</label>
                            <select class="form-select col-4" aria-label="Default select example" id="state" name="state">
                            <option value="<?php echo $result1['state']; ?>"><?php echo $result1['state']; ?></option>
                                        <option value="Kerala">Kerala</option>
                                        <option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Puducherry">Puducherry</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="West Bengal">West Bengal</option>

                                        </select>     
                        </div>
                        <!-- Form Row-->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (phone number)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputPhone">country</label>
                                <select class="form-select col-4" aria-label="Default select example" id="country" name="country">
                                <option value="<?php echo $result1['country']; ?>"><?php echo $result1['country']; ?></option>       
                                <option value="India">India</option>
                                        </select>    
                            </div>
                            <!-- Form Group (birthday)-->
                            <!-- Form Group (first name)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputFirstName">District</label>
                                <input class="form-control" id="inputFirstName" type="text" name="dist" placeholder="Enter your district" value="<?php echo $result1['district']; ?>" required>
                            </div>
            
                        </div>
                        <!-- Save changes button-->
                        <button class="btn btn-primary" name="upprofile" type="submit">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    </html>
    <?php
include("connect.php");

  if(isset($_POST["upprofile"]))
  {

    
    $fname=$_POST["fname"];
    $Username=$_POST["uname"];
   
    $email=$_POST["emails"];
    $phone=$_POST["phoneno"];
   
    $place=$_POST["place"];
    $state=$_POST["state"];
    $country=$_POST["country"];
    $dist=$_POST["dist"];
    $idd=$_SESSION['uid'];
   

    $sql=" UPDATE `registration` SET `name`='$fname',`username`='$Username',
    `email`='$email',`phone`='$phone',`place`='$place',`state`='$state',`country`='$country',`district`='$dist' WHERE id='$idd'";

  if(mysqli_query($con,$sql))
  {
    ?>
    <script>
        alert("Updated");
    </script>
    <?php
      echo "<script>window.location.href='editprofile.php';</script>";
  }
  else
  {
    echo "error";
  }
    }
  ?>
