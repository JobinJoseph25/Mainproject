<?php

include 'connect.php';

if (isset($_GET['term'])) {
     
   $query = "SELECT * FROM tbl_place WHERE places LIKE '{$_GET['term']}%' LIMIT 25";
    $result = mysqli_query($con, $query);
 
   
    if (mysqli_num_rows($result) > 0) {
     while ($product = mysqli_fetch_array($result)) {
      $results[] = $product['places'];
     }
    } else {
      $results = array();
    }
    //return json results
    echo json_encode($results);
}
?>