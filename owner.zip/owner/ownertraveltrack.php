<?php
include 'nav.php';
include 'connect.php';

?>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">     
    $(document).ready(function() {
    $('#example').DataTable();
    } );
    </script>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

  </head>
<body ><div class="container">
<div class="row">
        <div class="col-lg-12" style="margin-top: 50px; margin-bottom: 50px;">
         
            <h2>My Travel Status</h2>

            <!--Start table -->
            <table id="example" class="table table-striped "  >

                <thead>
                  <tr>
                    <!-- <th scope="col">ID</th> -->
                    <th scope="col">From</th>
                    
                    <th scope="col">Routs</th>
                    <th scope="col">To</th>
                    <th scope="col">Date</th>
                    <th scope="col">Time</th>
                    <th scope="col">no_of_seats</th>
                    <th scope="col">Rate</th>
                    
                    <th scope="col">    </th>
                    <!-- <th scope="col">Add Date</th>
                    <th scope="col">Price</th> -->
                    
                              <!-- <th scope="col">Drop</th> -->
                  </tr>
                </thead>
                <tbody>
                    <?php
                       $usid=$_SESSION['uid'];
                    $query2=mysqli_query($con,"select * from addtraveldetails where t_uid='$usid'");  
    while($result=mysqli_fetch_array($query2))
  { 
    echo'<tr>';
     
    echo "<td style='color: red;'>".$result['froms']."</td>";
   
    echo "<td>".$result['routs']."</td>";
    echo "<td style='color: red;'>".$result['tos']."</td>";
    echo "<td>".$result['dates']."</td>";
    echo "<td>".$result['times']."</td>";
    echo "<td>".$result['no_of_seats']."</td>";
    echo "<td>".$result['amount']."</td>";
   // echo "<td><img width='100px' height='100px' src='vehicleimg/".$result['imgpath']."'</td>";
    echo "<td><form method='POST' action='travelrequest.php'><input type='hidden' name='vid' value=".$result['tvlid']."><input type='submit' name='Ed1' value='View' class='btn btn-success btn-sm'>&nbsp;&nbsp;
    </form></td>";
    
    echo'</tr>';
?>

 <?php
  }
?> 
                
            </tbody>  
            </table>
            <!--end table -->

        </div>
      </div></div>
</body>
    </html>

    <?php
