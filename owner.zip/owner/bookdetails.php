<?php 
include("nav.php");
include("connect.php");
?>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;
}
</style>
</head>
<body>
<center>
<h2>Booking Details</h2>
<?php
$k=$_GET['usrid'];
$query2=mysqli_query($con,"select * from vhlbooking where bkid='$k'");
$res=mysqli_fetch_array($query2);
$tvlid=$res['travelid'];
$g=mysqli_query($con,"select addvehicle.imgpath,addtraveldetails.tvlid from addvehicle,addtraveldetails where (addvehicle.vid=addtraveldetails.t_vid) and (addtraveldetails.tvlid='$tvlid')");
$re=mysqli_fetch_array($g);
?>

<table style="width:50%">
<tr>
    <th>Vehicle Image</th>
    <td><img src="<?php echo 'vehicleimg/'.$re['imgpath']; ?>"></td>
  </tr>
  <tr>
    <th>From:</th>
    <td><?php echo $res['frm']; ?></td>
  </tr>
  <tr>
    <th>To:</th>
    <td><?php echo $res['ttoo']; ?></td>
  </tr>
  <tr>
    <th>Routs:</th>
    <td><?php echo $res['rrouts']; ?></td>
  </tr>
  <tr>
    <th>pickupdest:</th>
    <td><?php echo $res['pickupdest']; ?></td>
  </tr>
  <tr>
    <th>date:</th>
    <td><?php echo $res['ddate']; ?></td>
  </tr>
  <tr>
    <th>time:</th>
    <td><?php echo $res['ttime']; ?></td>
  </tr>
  <tr>
    <th>amount:</th>
    <td><?php echo $res['aamount']; ?></td>
  </tr>
  <tr>
    <th>Seats:</th>
    <td><?php echo $res['sseatsneeded']; ?></td>
  </tr>
</table>
</center>
</body>
</html>