<html>
<head>
	<title>MY WEBSITE</title>
<link rel="stylesheet" type="text/css" href="styleindex.css">

</head>
<body>
	<div class="banner-area">
		<header>
			<a href="#" class="logo">Vehicle Sharing Service</a>
			<ul class="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="abt.php">About Us</a></li>
			</ul>
		</header>
		<div class="banner-text">
			<h2>Vehicle Sharing Service</h2>
			<p>Welcome Back Keep share on your daily Rides</p>
			<a href="reg.php">Sign UP</a>
			<a href="log.php">Login</a>
		</div>
	</div>

</body>
</html>

