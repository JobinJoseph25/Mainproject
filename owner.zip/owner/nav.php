<?php
session_start();

$tt1=$_SESSION['nnm'];
$ii=$_SESSION['prof'];
?>

<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
   <!--------- <title>Responsive Navigation Menu</title>------>
    <link rel="stylesheet" href="stylenav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

  </head>
  <body>
    <nav>
  

      <div class="logo" ><img src="logo.jpg" style="height:50px">
      Vshare</div>

      <input type="checkbox" id="click">
      <label for="click" class="menu-btn">
        <i class="fas fa-bars"></i>
      </label>
      <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="addvehicle.php">Add</a></li>
      
          <li><a href="ownertraveltrack.php">Track</a></li>

          <li><a href="bookings.php">Bookings</a></li>
        <li><a href="editprofile.php">Profile</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="logout.php">Logout</a></li>
        <li><img src="propic/<?php echo $ii; ?>" style="height:50px;border-radius:50%;color:red;" >
     <?php echo $tt1; ?>
      </li>
     

       <li><h3><b style="color: #F8FF13;"></b></h3></li>

      </ul>
    </nav>

  </body>
</html>

